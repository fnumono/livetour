# Agora Live 2.1 (Agoroom)

> Agora Live in vanilla Javascript

## Build Setup

``` bash
# install dependencies
npm install

# serve with hot reload at localhost:8080
npm run dev

# use eslint and prettier to improve code quality
npm run lint
npm run format

# unit testing
npm run test

# build for production with minification
npm run build
```
